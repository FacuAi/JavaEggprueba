import { BrowserRouter,  Routes, Route} from 'react-router-dom'
import './App.css'
import Footer from './components/Footer'
import Main1 from './components/Main1'
import Main2 from './components/Main2'
import Navbar from './components/Navbar'

function App() {

  return (
    <div>
      <h1>Ejercicio 4</h1>

      <BrowserRouter>
      <Navbar />
     
        <Routes> 
          <Route path="/main1" element={<Main1 />} />
          <Route path="/main2" element={<Main2 />} />
        </Routes>
      
      <Footer />
    </BrowserRouter>  
    </div >
  )
}

export default App
