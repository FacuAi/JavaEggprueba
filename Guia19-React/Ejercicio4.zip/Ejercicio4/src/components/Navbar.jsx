import React from 'react'
import {Link} from "react-router-dom"
export default function Navbar() {
    return (
        <div>
            <nav>
                <ul>
                    <li> <a href='/main1'>Main 1 </a>  </li>
                    <li> <a href='/main2'> Main 2 </a> </li>

                </ul>
            </nav>
        </div>
    )
}
