import React from 'react'

export default function Main1() {
  return (
    <div>
      <h1>Probando main 1</h1>
    </div>
  )
}
