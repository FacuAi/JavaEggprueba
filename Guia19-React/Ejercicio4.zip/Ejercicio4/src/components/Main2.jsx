import React from 'react'

export default function Main2() {
  return (
    <div>
      <h2>Seré main 2?</h2>
    </div>
  )
}
