import { useState } from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)
  const incrementar = ()=> {
    setCount(count+1);
  }
  const achicar = ()=> {
    setCount(count-1);
  }
  const [numberInput, setNumberInput] = useState(0);

  const dekremento = (event) => {
    const newValue = parseInt(event.target.value, 10);
    setNumberInput(newValue || 0); // Para asegurarse de que el valor sea un número
  };

  return (
    <> <h1>Contador de clicks:</h1>
     <button onClick={incrementar}>Aumentar</button>
     <button onClick={achicar}>Reducir</button>
      <p>Contador: {count}</p>

      <h2>Input de Número</h2>
      <input type="number" value={numberInput} onChange={dekremento} placeholder="Ingresa un número"/>
      <p>Número ingresado: {numberInput}</p>
    </>
  )
  }

export default App 
  
